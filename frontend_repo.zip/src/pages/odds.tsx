import withAuth from '../utils/withAuth';
import Layout from '../components/Layout';
import { useQuery, useMutation } from 'react-query';
import { oddsAPI } from '../utils/api';
import { FiRefreshCw, FiFilter } from 'react-icons/fi';
import { toast } from 'react-toastify';
import { format } from 'date-fns';
import { useState } from 'react';

const Odds = () => {
  const [selectedSport, setSelectedSport] = useState<string>('');
  const [selectedSportsbook, setSelectedSportsbook] = useState<string>('');
  
  // Fetch latest odds
  const { data: odds, isLoading, isError, refetch } = useQuery(
    ['latestOdds', selectedSport, selectedSportsbook],
    () => oddsAPI.getLatestOdds(selectedSport, selectedSportsbook)
      .then(res => res.data),
    {
      refetchInterval: 60000, // Refetch every minute
    }
  );
  
  // Refresh odds
  const refreshMutation = useMutation(
    () => oddsAPI.refreshOdds(),
    {
      onSuccess: () => {
        toast.success('Odds refreshed successfully');
        refetch();
      },
      onError: () => {
        toast.error('Failed to refresh odds');
      }
    }
  );
  
  const handleRefresh = () => {
    refreshMutation.mutate();
  };
  
  const sportOptions = [
    { value: '', label: 'All Sports' },
    { value: 'basketball', label: 'Basketball' },
    { value: 'football', label: 'Football' },
    { value: 'baseball', label: 'Baseball' },
    { value: 'hockey', label: 'Hockey' },
    { value: 'soccer', label: 'Soccer' },
  ];
  
  const sportsbookOptions = [
    { value: '', label: 'All Sportsbooks' },
    { value: 'DraftKings', label: 'DraftKings' },
    { value: 'FanDuel', label: 'FanDuel' },
    { value: 'BetMGM', label: 'BetMGM' },
    { value: 'Caesars', label: 'Caesars' },
    { value: 'PointsBet', label: 'PointsBet' },
  ];
  
  if (isLoading) {
    return (
      <Layout title="Latest Odds | Sports Betting Arbitrage">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
        </div>
      </Layout>
    );
  }
  
  if (isError) {
    return (
      <Layout title="Latest Odds | Sports Betting Arbitrage">
        <div className="bg-red-50 p-4 rounded-md">
          <p className="text-red-700">Error loading odds</p>
          <button 
            onClick={() => refetch()} 
            className="mt-2 px-4 py-2 bg-red-100 text-red-700 rounded-md hover:bg-red-200"
          >
            Try Again
          </button>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout title="Latest Odds | Sports Betting Arbitrage">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Latest Odds</h1>
        <p className="text-gray-600">View the most recent odds from all sportsbooks</p>
      </div>
      
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <div className="p-4 border-b flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <h2 className="text-lg font-semibold text-gray-800">Odds Data</h2>
          
          <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-4">
            <div className="flex items-center space-x-2">
              <FiFilter className="text-gray-500" />
              <select
                value={selectedSport}
                onChange={(e) => setSelectedSport(e.target.value)}
                className="border rounded-md px-2 py-1 text-sm"
              >
                {sportOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="flex items-center space-x-2">
              <FiFilter className="text-gray-500" />
              <select
                value={selectedSportsbook}
                onChange={(e) => setSelectedSportsbook(e.target.value)}
                className="border rounded-md px-2 py-1 text-sm"
              >
                {sportsbookOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
            
            <button
              onClick={handleRefresh}
              disabled={refreshMutation.isLoading}
              className="flex items-center space-x-1 px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 disabled:opacity-50"
            >
              <FiRefreshCw className={refreshMutation.isLoading ? "animate-spin" : ""} />
              <span>Refresh</span>
            </button>
          </div>
        </div>
        
        {odds && odds.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Event
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Sportsbook
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Outcome
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Odds
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Last Updated
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {odds.map((odd) => (
                  <tr key={odd.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {odd.event.name}
                      </div>
                      <div className="text-xs text-gray-500">
                        {odd.event.sport} | {odd.event.league}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {odd.sportsbook.name}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {odd.outcome}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-primary-600">
                        {odd.odds_american > 0 ? `+${odd.odds_american}` : odd.odds_american}
                      </div>
                      <div className="text-xs text-gray-500">
                        {odd.odds_decimal.toFixed(2)} (decimal)
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {format(new Date(odd.last_updated), 'MMM d, h:mm a')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-8 text-center">
            <p className="text-gray-500">No odds data found</p>
            <p className="text-sm text-gray-400 mt-2">Try adjusting your filters or refreshing the data</p>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default withAuth(Odds);
