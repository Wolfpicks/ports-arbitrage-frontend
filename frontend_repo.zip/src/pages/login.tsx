import Layout from '../components/Layout';
import LoginForm from '../components/LoginForm';

const Login = () => {
  return (
    <Layout title="Login | Sports Betting Arbitrage">
      <div className="flex justify-center items-center min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <LoginForm />
      </div>
    </Layout>
  );
};

export default Login;
