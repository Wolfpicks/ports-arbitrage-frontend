import Layout from '../components/Layout';
import ArbitrageTable from '../components/ArbitrageTable';

const Arbitrage = () => {
  return (
    <Layout title="Arbitrage Opportunities | Sports Betting Arbitrage">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Arbitrage Opportunities</h1>
        <p className="text-gray-600">Find and track profitable betting opportunities across sportsbooks</p>
      </div>
      
      <ArbitrageTable />
    </Layout>
  );
};

export default Arbitrage;
