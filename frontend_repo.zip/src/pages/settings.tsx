import withAuth from '../utils/withAuth';
import Layout from '../components/Layout';
import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';

const Settings = () => {
  const { user, logout } = useAuth();
  const [minProfitMargin, setMinProfitMargin] = useState(1.0);
  const [defaultStake, setDefaultStake] = useState(100);
  const [emailNotifications, setEmailNotifications] = useState(false);
  
  const handleSaveSettings = () => {
    // In a real implementation, this would save to the backend
    toast.success('Settings saved successfully');
  };
  
  return (
    <Layout title="Settings | Sports Betting Arbitrage">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Settings</h1>
        <p className="text-gray-600">Manage your account and application preferences</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Account Settings */}
        <div className="md:col-span-2">
          <div className="bg-white shadow-md rounded-lg overflow-hidden">
            <div className="p-4 border-b">
              <h2 className="text-lg font-semibold text-gray-800">Account Settings</h2>
            </div>
            <div className="p-6">
              <div className="mb-6">
                <h3 className="text-md font-medium text-gray-800 mb-2">Account Information</h3>
                <div className="bg-gray-50 p-4 rounded-md">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Email</p>
                      <p className="text-md font-medium">{user?.email}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Account Created</p>
                      <p className="text-md font-medium">
                        {user?.created_at ? new Date(user.created_at).toLocaleDateString() : 'N/A'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-md font-medium text-gray-800 mb-2">Arbitrage Preferences</h3>
                <div className="space-y-4">
                  <div>
                    <label htmlFor="minProfitMargin" className="block text-sm font-medium text-gray-700 mb-1">
                      Minimum Profit Margin (%)
                    </label>
                    <input
                      id="minProfitMargin"
                      type="number"
                      min="0.1"
                      step="0.1"
                      value={minProfitMargin}
                      onChange={(e) => setMinProfitMargin(parseFloat(e.target.value))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                    />
                    <p className="mt-1 text-sm text-gray-500">
                      Only show arbitrage opportunities with profit margin above this threshold
                    </p>
                  </div>
                  
                  <div>
                    <label htmlFor="defaultStake" className="block text-sm font-medium text-gray-700 mb-1">
                      Default Stake ($)
                    </label>
                    <input
                      id="defaultStake"
                      type="number"
                      min="1"
                      step="1"
                      value={defaultStake}
                      onChange={(e) => setDefaultStake(parseInt(e.target.value))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                    />
                    <p className="mt-1 text-sm text-gray-500">
                      Default amount to use for stake calculations
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-md font-medium text-gray-800 mb-2">Notification Settings</h3>
                <div className="flex items-center">
                  <input
                    id="emailNotifications"
                    type="checkbox"
                    checked={emailNotifications}
                    onChange={(e) => setEmailNotifications(e.target.checked)}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                  />
                  <label htmlFor="emailNotifications" className="ml-2 block text-sm text-gray-700">
                    Receive email notifications for new arbitrage opportunities
                  </label>
                </div>
              </div>
              
              <div className="flex justify-end">
                <button
                  onClick={handleSaveSettings}
                  className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700"
                >
                  Save Settings
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Account Actions */}
        <div>
          <div className="bg-white shadow-md rounded-lg overflow-hidden">
            <div className="p-4 border-b">
              <h2 className="text-lg font-semibold text-gray-800">Account Actions</h2>
            </div>
            <div className="p-6">
              <div className="space-y-4">
                <button
                  onClick={() => toast.info('Password reset email sent')}
                  className="w-full px-4 py-2 bg-gray-100 text-gray-800 rounded-md hover:bg-gray-200 flex justify-center"
                >
                  Change Password
                </button>
                
                <button
                  onClick={logout}
                  className="w-full px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 flex justify-center"
                >
                  Logout
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default withAuth(Settings);
