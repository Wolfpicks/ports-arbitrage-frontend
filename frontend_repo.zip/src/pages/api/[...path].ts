import { NextApiRequest, NextApiResponse } from 'next';
import axios from 'axios';
import Cookies from 'js-cookie';

// This middleware will run on API routes to proxy requests to the backend
export default async function apiMiddleware(req: NextApiRequest, res: NextApiResponse) {
  const { method, url, headers, body } = req;
  const backendUrl = process.env.BACKEND_URL || 'http://localhost:8000';
  
  try {
    // Get the API path from the URL
    const apiPath = url?.replace('/api', '') || '';
    
    // Get auth token from cookies if available
    const token = req.cookies.token;
    
    // Set up headers for the backend request
    const requestHeaders: any = {
      ...headers,
      'Content-Type': 'application/json',
    };
    
    // Add authorization header if token exists
    if (token) {
      requestHeaders.Authorization = `Bearer ${token}`;
    }
    
    // Make the request to the backend
    const response = await axios({
      method: method,
      url: `${backendUrl}${apiPath}`,
      headers: requestHeaders,
      data: method !== 'GET' ? body : undefined,
      params: method === 'GET' ? body : undefined,
    });
    
    // Return the response from the backend
    return res.status(response.status).json(response.data);
  } catch (error) {
    console.error('API middleware error:', error);
    
    // Handle errors from the backend
    if (axios.isAxiosError(error) && error.response) {
      return res.status(error.response.status).json(error.response.data);
    }
    
    // Handle other errors
    return res.status(500).json({ message: 'Internal server error' });
  }
}
