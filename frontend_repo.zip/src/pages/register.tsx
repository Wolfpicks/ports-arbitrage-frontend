import Layout from '../components/Layout';
import RegisterForm from '../components/RegisterForm';

const Register = () => {
  return (
    <Layout title="Register | Sports Betting Arbitrage">
      <div className="flex justify-center items-center min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <RegisterForm />
      </div>
    </Layout>
  );
};

export default Register;
