import withAuth from '../utils/withAuth';
import Layout from '../components/Layout';
import { useQuery, useMutation } from 'react-query';
import { arbitrageAPI, oddsAPI } from '../utils/api';
import { FiRefreshCw } from 'react-icons/fi';
import { toast } from 'react-toastify';

const Refresh = () => {
  // Refresh odds mutation
  const refreshOddsMutation = useMutation(
    () => oddsAPI.refreshOdds(),
    {
      onSuccess: () => {
        toast.success('Odds data refreshed successfully');
      },
      onError: () => {
        toast.error('Failed to refresh odds data');
      }
    }
  );
  
  // Calculate arbitrage mutation
  const calculateArbitrageMutation = useMutation(
    () => arbitrageAPI.calculateArbitrageOpportunities(),
    {
      onSuccess: () => {
        toast.success('Arbitrage opportunities calculated successfully');
      },
      onError: () => {
        toast.error('Failed to calculate arbitrage opportunities');
      }
    }
  );
  
  // Handle refresh all data
  const handleRefreshAll = async () => {
    try {
      toast.info('Starting data refresh...');
      await refreshOddsMutation.mutateAsync();
      await calculateArbitrageMutation.mutateAsync();
      toast.success('All data refreshed successfully!');
    } catch (error) {
      toast.error('Error during data refresh');
    }
  };
  
  return (
    <Layout title="Refresh Data | Sports Betting Arbitrage">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Refresh Data</h1>
        <p className="text-gray-600">Update odds data and calculate new arbitrage opportunities</p>
      </div>
      
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <div className="p-6">
          <div className="mb-8">
            <h2 className="text-lg font-semibold text-gray-800 mb-2">Refresh Options</h2>
            <p className="text-gray-600 mb-4">
              Choose which data you want to refresh. Refreshing odds data will fetch the latest odds from all sportsbooks.
              Calculating arbitrage opportunities will analyze the latest odds to find profitable betting opportunities.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                <h3 className="font-medium text-gray-800 mb-2">Refresh Odds Data</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Fetch the latest odds from all supported sportsbooks.
                </p>
                <button
                  onClick={() => refreshOddsMutation.mutate()}
                  disabled={refreshOddsMutation.isLoading}
                  className="w-full flex items-center justify-center space-x-2 px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 disabled:opacity-50"
                >
                  <FiRefreshCw className={refreshOddsMutation.isLoading ? "animate-spin" : ""} />
                  <span>{refreshOddsMutation.isLoading ? 'Refreshing...' : 'Refresh Odds'}</span>
                </button>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                <h3 className="font-medium text-gray-800 mb-2">Calculate Arbitrage</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Calculate arbitrage opportunities from the latest odds data.
                </p>
                <button
                  onClick={() => calculateArbitrageMutation.mutate()}
                  disabled={calculateArbitrageMutation.isLoading}
                  className="w-full flex items-center justify-center space-x-2 px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 disabled:opacity-50"
                >
                  <FiRefreshCw className={calculateArbitrageMutation.isLoading ? "animate-spin" : ""} />
                  <span>{calculateArbitrageMutation.isLoading ? 'Calculating...' : 'Calculate Arbitrage'}</span>
                </button>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                <h3 className="font-medium text-gray-800 mb-2">Refresh All Data</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Refresh odds data and calculate arbitrage opportunities in one go.
                </p>
                <button
                  onClick={handleRefreshAll}
                  disabled={refreshOddsMutation.isLoading || calculateArbitrageMutation.isLoading}
                  className="w-full flex items-center justify-center space-x-2 px-4 py-2 bg-secondary-600 text-white rounded-md hover:bg-secondary-700 disabled:opacity-50"
                >
                  <FiRefreshCw className={(refreshOddsMutation.isLoading || calculateArbitrageMutation.isLoading) ? "animate-spin" : ""} />
                  <span>{(refreshOddsMutation.isLoading || calculateArbitrageMutation.isLoading) ? 'Processing...' : 'Refresh All'}</span>
                </button>
              </div>
            </div>
          </div>
          
          <div>
            <h2 className="text-lg font-semibold text-gray-800 mb-2">Data Refresh Schedule</h2>
            <p className="text-gray-600 mb-4">
              The system automatically refreshes data on the following schedule:
            </p>
            
            <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
              <ul className="space-y-2">
                <li className="flex items-start">
                  <span className="text-primary-600 font-medium mr-2">•</span>
                  <span className="text-gray-700">Odds data is refreshed every 5 minutes</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary-600 font-medium mr-2">•</span>
                  <span className="text-gray-700">Arbitrage opportunities are calculated after each odds refresh</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary-600 font-medium mr-2">•</span>
                  <span className="text-gray-700">Manual refresh is available anytime for immediate updates</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default withAuth(Refresh);
