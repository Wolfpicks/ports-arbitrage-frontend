import { useEffect } from 'react';
import { useRouter } from 'next/router';
import withAuth from '../utils/withAuth';
import Layout from '../components/Layout';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { favoritesAPI, arbitrageAPI } from '../utils/api';
import { FiTrash2, FiRefreshCw } from 'react-icons/fi';
import { toast } from 'react-toastify';
import { format } from 'date-fns';

const Favorites = () => {
  const router = useRouter();
  const queryClient = useQueryClient();
  
  // Fetch user's favorites
  const { data: favorites, isLoading, isError, refetch } = useQuery(
    'favorites',
    () => favoritesAPI.getFavorites().then(res => res.data),
    {
      refetchInterval: 60000, // Refetch every minute
    }
  );
  
  // Remove from favorites
  const removeFavoriteMutation = useMutation(
    (favoriteId: number) => favoritesAPI.removeFavorite(favoriteId),
    {
      onSuccess: () => {
        toast.success('Removed from favorites');
        queryClient.invalidateQueries('favorites');
      },
      onError: () => {
        toast.error('Failed to remove from favorites');
      }
    }
  );
  
  const handleRemoveFavorite = (favoriteId: number) => {
    removeFavoriteMutation.mutate(favoriteId);
  };
  
  if (isLoading) {
    return (
      <Layout title="Favorites | Sports Betting Arbitrage">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
        </div>
      </Layout>
    );
  }
  
  if (isError) {
    return (
      <Layout title="Favorites | Sports Betting Arbitrage">
        <div className="bg-red-50 p-4 rounded-md">
          <p className="text-red-700">Error loading favorites</p>
          <button 
            onClick={() => refetch()} 
            className="mt-2 px-4 py-2 bg-red-100 text-red-700 rounded-md hover:bg-red-200"
          >
            Try Again
          </button>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout title="Favorites | Sports Betting Arbitrage">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Favorites</h1>
        <p className="text-gray-600">Your saved arbitrage opportunities</p>
      </div>
      
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <div className="p-4 border-b flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-800">Saved Opportunities</h2>
          <button
            onClick={() => refetch()}
            className="flex items-center space-x-1 px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700"
          >
            <FiRefreshCw />
            <span>Refresh</span>
          </button>
        </div>
        
        {favorites && favorites.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Event
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Profit
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Outcomes
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Saved At
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {favorites.map((favorite) => (
                  <tr key={favorite.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {favorite.arbitrage.event.name}
                      </div>
                      <div className="text-xs text-gray-500">
                        {favorite.arbitrage.event.sport} | {favorite.arbitrage.event.league}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-success-600">
                        +{favorite.arbitrage.profit_margin.toFixed(2)}%
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="space-y-2">
                        {Object.entries(favorite.arbitrage.outcome_details).map(([outcome, details]) => (
                          <div key={outcome} className="flex flex-col">
                            <div className="text-sm font-medium text-gray-900 flex justify-between">
                              <span>{outcome}</span>
                              <span className="text-primary-600">{details.odds_american > 0 ? `+${details.odds_american}` : details.odds_american}</span>
                            </div>
                            <div className="text-xs text-gray-500 flex justify-between">
                              <span>{details.sportsbook}</span>
                              <span>Stake: ${details.optimal_stake.toFixed(2)}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {format(new Date(favorite.created_at), 'MMM d, h:mm a')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button
                        onClick={() => handleRemoveFavorite(favorite.id)}
                        className="text-red-600 hover:text-red-900 flex items-center space-x-1"
                      >
                        <FiTrash2 />
                        <span>Remove</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-8 text-center">
            <p className="text-gray-500">No favorites found</p>
            <p className="text-sm text-gray-400 mt-2">Save arbitrage opportunities to view them here</p>
            <button
              onClick={() => router.push('/arbitrage')}
              className="mt-4 px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700"
            >
              Browse Opportunities
            </button>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default withAuth(Favorites);
