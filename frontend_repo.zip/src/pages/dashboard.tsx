import { useEffect } from 'react';
import { useQuery } from 'react-query';
import { arbitrageAPI, oddsAPI } from '../utils/api';
import Layout from '../components/Layout';
import ArbitrageTable from '../components/ArbitrageTable';
import { FiTrendingUp, FiDatabase, FiRefreshCw, FiPieChart } from 'react-icons/fi';
import { toast } from 'react-toastify';

const Dashboard = () => {
  const { data: arbitrageOpportunities, isLoading: isLoadingArbitrage } = useQuery(
    'arbitrageOpportunities',
    () => arbitrageAPI.getArbitrageOpportunities().then(res => res.data),
    {
      refetchInterval: 60000, // Refetch every minute
    }
  );

  const { data: latestOdds, isLoading: isLoadingOdds } = useQuery(
    'latestOdds',
    () => oddsAPI.getLatestOdds().then(res => res.data),
    {
      refetchInterval: 60000, // Refetch every minute
    }
  );

  // Calculate stats
  const stats = {
    totalArbitrageOpportunities: arbitrageOpportunities?.length || 0,
    highestProfitMargin: arbitrageOpportunities?.length 
      ? Math.max(...arbitrageOpportunities.map(opp => opp.profit_margin))
      : 0,
    totalSportsbooks: latestOdds?.length 
      ? new Set(latestOdds.map(odd => odd.sportsbook.name)).size
      : 0,
    totalEvents: latestOdds?.length 
      ? new Set(latestOdds.map(odd => odd.event.id)).size
      : 0,
  };

  // Refresh data on initial load
  useEffect(() => {
    const refreshData = async () => {
      try {
        await oddsAPI.refreshOdds();
        await arbitrageAPI.calculateArbitrageOpportunities();
        toast.success('Data refreshed successfully');
      } catch (error) {
        toast.error('Failed to refresh data');
      }
    };

    refreshData();
  }, []);

  return (
    <Layout title="Dashboard | Sports Betting Arbitrage">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
        <p className="text-gray-600">Overview of arbitrage opportunities and betting data</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-primary-100 text-primary-600">
              <FiTrendingUp className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Arbitrage Opportunities</p>
              <p className="text-2xl font-semibold text-gray-800">
                {isLoadingArbitrage ? '...' : stats.totalArbitrageOpportunities}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-success-100 text-success-600">
              <FiPieChart className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Highest Profit Margin</p>
              <p className="text-2xl font-semibold text-gray-800">
                {isLoadingArbitrage ? '...' : `${stats.highestProfitMargin.toFixed(2)}%`}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-secondary-100 text-secondary-600">
              <FiDatabase className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Sportsbooks</p>
              <p className="text-2xl font-semibold text-gray-800">
                {isLoadingOdds ? '...' : stats.totalSportsbooks}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-danger-100 text-danger-600">
              <FiRefreshCw className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Events Tracked</p>
              <p className="text-2xl font-semibold text-gray-800">
                {isLoadingOdds ? '...' : stats.totalEvents}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Arbitrage Opportunities Table */}
      <ArbitrageTable />
    </Layout>
  );
};

export default Dashboard;
