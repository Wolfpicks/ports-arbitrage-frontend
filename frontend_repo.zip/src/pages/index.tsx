import { NextPage } from 'next';
import { useEffect } from 'react';
import Link from 'next/link';
import Layout from '../components/Layout';
import { FiTrendingUp, FiBarChart2, FiUsers, FiArrowRight } from 'react-icons/fi';

const Home: NextPage = () => {
  return (
    <Layout title="Sports Betting Arbitrage | Find Profitable Betting Opportunities">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-primary-600 to-primary-800 text-white py-16 px-4 sm:px-6 lg:px-8 rounded-lg mb-12">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl md:text-6xl">
            Find Guaranteed Profits in Sports Betting
          </h1>
          <p className="mt-6 text-xl max-w-2xl mx-auto">
            ArbitrageHub helps you identify and capitalize on arbitrage opportunities across multiple sportsbooks, ensuring risk-free profits regardless of the outcome.
          </p>
          <div className="mt-10 flex justify-center">
            <Link href="/register" className="px-8 py-3 border border-transparent text-base font-medium rounded-md text-primary-700 bg-white hover:bg-gray-50 md:py-4 md:text-lg md:px-10">
              Get Started
            </Link>
            <Link href="/login" className="ml-4 px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-primary-700 hover:bg-primary-800 md:py-4 md:text-lg md:px-10">
              Login
            </Link>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              How ArbitrageHub Works
            </h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
              Our platform automates the process of finding and analyzing arbitrage opportunities across major sportsbooks.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            <div className="bg-white overflow-hidden shadow rounded-lg">
              <div className="px-4 py-5 sm:p-6">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary-500 text-white mb-5">
                  <FiBarChart2 className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-medium text-gray-900">Real-time Odds Tracking</h3>
                <p className="mt-2 text-base text-gray-500">
                  We continuously monitor odds from major sportsbooks, ensuring you have the most up-to-date information.
                </p>
              </div>
            </div>

            <div className="bg-white overflow-hidden shadow rounded-lg">
              <div className="px-4 py-5 sm:p-6">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary-500 text-white mb-5">
                  <FiTrendingUp className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-medium text-gray-900">Arbitrage Calculation</h3>
                <p className="mt-2 text-base text-gray-500">
                  Our algorithms automatically identify profitable arbitrage opportunities and calculate optimal stake allocation.
                </p>
              </div>
            </div>

            <div className="bg-white overflow-hidden shadow rounded-lg">
              <div className="px-4 py-5 sm:p-6">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary-500 text-white mb-5">
                  <FiUsers className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-medium text-gray-900">User-friendly Interface</h3>
                <p className="mt-2 text-base text-gray-500">
                  Access arbitrage opportunities through our intuitive dashboard, with detailed information and filtering options.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gray-50 py-12 px-4 sm:px-6 lg:py-16 lg:px-8 rounded-lg">
        <div className="max-w-7xl mx-auto lg:flex lg:items-center lg:justify-between">
          <h2 className="text-3xl font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            <span className="block">Ready to start earning?</span>
            <span className="block text-primary-600">Create your account today.</span>
          </h2>
          <div className="mt-8 flex lg:mt-0 lg:flex-shrink-0">
            <div className="inline-flex rounded-md shadow">
              <Link href="/register" className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700">
                Get Started
                <FiArrowRight className="ml-2 -mr-1 h-5 w-5" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Home;
