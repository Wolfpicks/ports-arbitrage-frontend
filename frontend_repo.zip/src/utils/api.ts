import axios from 'axios';
import Cookies from 'js-cookie';

// Create axios instance with base URL
const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || '/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add request interceptor to add auth token to requests
api.interceptors.request.use(
  (config) => {
    const token = Cookies.get('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor to handle errors
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    // Handle 401 Unauthorized errors (token expired)
    if (error.response && error.response.status === 401) {
      Cookies.remove('token');
      if (typeof window !== 'undefined') {
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  login: (email, password) => 
    api.post('/auth/login', { username: email, password }),
  register: (email, password) => 
    api.post('/auth/register', { email, password }),
  getProfile: () => 
    api.get('/auth/me'),
};

// Arbitrage API
export const arbitrageAPI = {
  getArbitrageOpportunities: (minProfit, sport) => {
    let url = '/arbitrages';
    const params = new URLSearchParams();
    if (minProfit) params.append('min_profit', minProfit);
    if (sport) params.append('sport', sport);
    if (params.toString()) url += `?${params.toString()}`;
    return api.get(url);
  },
  calculateArbitrageOpportunities: () => 
    api.post('/arbitrages/calculate'),
};

// Odds API
export const oddsAPI = {
  getLatestOdds: (sport, sportsbook) => {
    let url = '/odds';
    const params = new URLSearchParams();
    if (sport) params.append('sport', sport);
    if (sportsbook) params.append('sportsbook', sportsbook);
    if (params.toString()) url += `?${params.toString()}`;
    return api.get(url);
  },
  refreshOdds: () => 
    api.post('/odds/refresh'),
};

// Events API
export const eventsAPI = {
  getEvents: (sport, league, status) => {
    let url = '/events';
    const params = new URLSearchParams();
    if (sport) params.append('sport', sport);
    if (league) params.append('league', league);
    if (status) params.append('status', status);
    if (params.toString()) url += `?${params.toString()}`;
    return api.get(url);
  },
  getEvent: (eventId) => 
    api.get(`/events/${eventId}`),
};

// Favorites API
export const favoritesAPI = {
  getFavorites: () => 
    api.get('/favorites'),
  addFavorite: (arbitrageId) => 
    api.post('/favorites', { arbitrage_id: arbitrageId }),
  removeFavorite: (favoriteId) => 
    api.delete(`/favorites/${favoriteId}`),
};

export default api;
