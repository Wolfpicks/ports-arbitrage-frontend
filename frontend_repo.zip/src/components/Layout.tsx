import { ReactNode } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { useAuth } from '../context/AuthContext';
import Navbar from './Navbar';
import Sidebar from './Sidebar';

interface LayoutProps {
  children: ReactNode;
  title?: string;
}

const Layout = ({ children, title = 'Sports Betting Arbitrage' }: LayoutProps) => {
  const { isAuthenticated, loading } = useAuth();
  const router = useRouter();
  
  // Public routes that don't require authentication
  const publicRoutes = ['/login', '/register', '/'];
  const isPublicRoute = publicRoutes.includes(router.pathname);
  
  // If loading, show loading screen
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }
  
  // If not authenticated and not on a public route, redirect to login
  if (!isAuthenticated && !isPublicRoute && typeof window !== 'undefined') {
    router.push('/login');
    return null;
  }
  
  // For public routes, render without sidebar
  if (isPublicRoute) {
    return (
      <>
        <Head>
          <title>{title}</title>
          <meta name="description" content="Sports Betting Arbitrage Application" />
          <link rel="icon" href="/favicon.ico" />
        </Head>
        <div className="min-h-screen bg-gray-50">
          <Navbar />
          <main className="container mx-auto px-4 py-8">
            {children}
          </main>
        </div>
      </>
    );
  }
  
  // For authenticated routes, render with sidebar
  return (
    <>
      <Head>
        <title>{title}</title>
        <meta name="description" content="Sports Betting Arbitrage Application" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar />
        <div className="flex-1">
          <Navbar />
          <main className="container mx-auto px-4 py-8">
            {children}
          </main>
        </div>
      </div>
    </>
  );
};

export default Layout;
