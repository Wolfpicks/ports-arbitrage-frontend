import { useRouter } from 'next/router';
import Link from 'next/link';
import { FiHome, FiTrendingUp, FiStar, FiSettings, FiRefreshCw, FiDatabase } from 'react-icons/fi';

const Sidebar = () => {
  const router = useRouter();
  
  const menuItems = [
    {
      name: 'Dashboard',
      icon: <FiHome className="w-5 h-5" />,
      href: '/dashboard',
    },
    {
      name: 'Arbitrage Opportunities',
      icon: <FiTrendingUp className="w-5 h-5" />,
      href: '/arbitrage',
    },
    {
      name: 'Favorites',
      icon: <FiStar className="w-5 h-5" />,
      href: '/favorites',
    },
    {
      name: 'Latest Odds',
      icon: <FiDatabase className="w-5 h-5" />,
      href: '/odds',
    },
    {
      name: 'Refresh Data',
      icon: <FiRefreshCw className="w-5 h-5" />,
      href: '/refresh',
    },
    {
      name: 'Settings',
      icon: <FiSettings className="w-5 h-5" />,
      href: '/settings',
    },
  ];
  
  return (
    <div className="hidden md:flex flex-col w-64 bg-white shadow-md">
      <div className="flex items-center justify-center h-16 border-b">
        <span className="text-xl font-bold text-primary-600">ArbitrageHub</span>
      </div>
      <div className="flex flex-col flex-1 overflow-y-auto">
        <nav className="flex-1 px-2 py-4 space-y-1">
          {menuItems.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className={`flex items-center px-4 py-3 text-sm font-medium rounded-md ${
                router.pathname === item.href
                  ? 'bg-primary-50 text-primary-600'
                  : 'text-gray-700 hover:bg-gray-50 hover:text-primary-600'
              }`}
            >
              <span className="mr-3">{item.icon}</span>
              {item.name}
            </Link>
          ))}
        </nav>
      </div>
    </div>
  );
};

export default Sidebar;
