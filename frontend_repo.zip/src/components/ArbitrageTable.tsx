import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { arbitrageAPI } from '../utils/api';
import { FiRefreshCw, FiFilter, FiStar } from 'react-icons/fi';
import { toast } from 'react-toastify';
import { format } from 'date-fns';
import { useAuth } from '../context/AuthContext';
import { favoritesAPI } from '../utils/api';

interface ArbitrageOpportunity {
  id: number;
  event: {
    id: number;
    name: string;
    sport: string;
    league: string;
    date: string;
  };
  profit_margin: number;
  outcome_details: Record<string, {
    sportsbook: string;
    odds_decimal: number;
    odds_american: number;
    implied_probability: number;
    optimal_stake: number;
  }>;
  detected_at: string;
}

const ArbitrageTable = () => {
  const { isAuthenticated } = useAuth();
  const queryClient = useQueryClient();
  const [minProfit, setMinProfit] = useState<number>(1);
  const [selectedSport, setSelectedSport] = useState<string>('');
  
  // Fetch arbitrage opportunities
  const { data: opportunities, isLoading, isError, refetch } = useQuery(
    ['arbitrageOpportunities', minProfit, selectedSport],
    () => arbitrageAPI.getArbitrageOpportunities(minProfit, selectedSport)
      .then(res => res.data),
    {
      refetchInterval: 60000, // Refetch every minute
    }
  );
  
  // Calculate arbitrage opportunities
  const calculateMutation = useMutation(
    () => arbitrageAPI.calculateArbitrageOpportunities(),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('arbitrageOpportunities');
        toast.success('Arbitrage opportunities calculated successfully');
      },
      onError: () => {
        toast.error('Failed to calculate arbitrage opportunities');
      }
    }
  );
  
  // Add to favorites
  const addFavoriteMutation = useMutation(
    (arbitrageId: number) => favoritesAPI.addFavorite(arbitrageId),
    {
      onSuccess: () => {
        toast.success('Added to favorites');
        queryClient.invalidateQueries('favorites');
      },
      onError: () => {
        toast.error('Failed to add to favorites');
      }
    }
  );
  
  const handleCalculate = () => {
    calculateMutation.mutate();
  };
  
  const handleAddFavorite = (arbitrageId: number) => {
    if (isAuthenticated) {
      addFavoriteMutation.mutate(arbitrageId);
    } else {
      toast.info('Please log in to add favorites');
    }
  };
  
  const sportOptions = [
    { value: '', label: 'All Sports' },
    { value: 'basketball', label: 'Basketball' },
    { value: 'football', label: 'Football' },
    { value: 'baseball', label: 'Baseball' },
    { value: 'hockey', label: 'Hockey' },
    { value: 'soccer', label: 'Soccer' },
  ];
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }
  
  if (isError) {
    return (
      <div className="bg-red-50 p-4 rounded-md">
        <p className="text-red-700">Error loading arbitrage opportunities</p>
        <button 
          onClick={() => refetch()} 
          className="mt-2 px-4 py-2 bg-red-100 text-red-700 rounded-md hover:bg-red-200"
        >
          Try Again
        </button>
      </div>
    );
  }
  
  return (
    <div className="bg-white shadow-md rounded-lg overflow-hidden">
      <div className="p-4 border-b flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
        <h2 className="text-lg font-semibold text-gray-800">Arbitrage Opportunities</h2>
        
        <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-4">
          <div className="flex items-center space-x-2">
            <FiFilter className="text-gray-500" />
            <select
              value={selectedSport}
              onChange={(e) => setSelectedSport(e.target.value)}
              className="border rounded-md px-2 py-1 text-sm"
            >
              {sportOptions.map(option => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
          
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-600">Min Profit:</span>
            <input
              type="number"
              min="0.1"
              step="0.1"
              value={minProfit}
              onChange={(e) => setMinProfit(parseFloat(e.target.value))}
              className="border rounded-md px-2 py-1 w-16 text-sm"
            />
            <span className="text-sm text-gray-600">%</span>
          </div>
          
          <button
            onClick={handleCalculate}
            disabled={calculateMutation.isLoading}
            className="flex items-center space-x-1 px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 disabled:opacity-50"
          >
            <FiRefreshCw className={calculateMutation.isLoading ? "animate-spin" : ""} />
            <span>Calculate</span>
          </button>
        </div>
      </div>
      
      {opportunities && opportunities.length > 0 ? (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Event
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Profit
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Outcomes
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Detected
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {opportunities.map((opportunity: ArbitrageOpportunity) => (
                <tr key={opportunity.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {opportunity.event.name}
                    </div>
                    <div className="text-xs text-gray-500">
                      {opportunity.event.sport} | {opportunity.event.league}
                    </div>
                    <div className="text-xs text-gray-500">
                      {format(new Date(opportunity.event.date), 'MMM d, yyyy h:mm a')}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-success-600">
                      +{opportunity.profit_margin.toFixed(2)}%
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="space-y-2">
                      {Object.entries(opportunity.outcome_details).map(([outcome, details]) => (
                        <div key={outcome} className="flex flex-col">
                          <div className="text-sm font-medium text-gray-900 flex justify-between">
                            <span>{outcome}</span>
                            <span className="text-primary-600">{details.odds_american > 0 ? `+${details.odds_american}` : details.odds_american}</span>
                          </div>
                          <div className="text-xs text-gray-500 flex justify-between">
                            <span>{details.sportsbook}</span>
                            <span>Stake: ${details.optimal_stake.toFixed(2)}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {format(new Date(opportunity.detected_at), 'MMM d, h:mm a')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button
                      onClick={() => handleAddFavorite(opportunity.id)}
                      className="text-primary-600 hover:text-primary-900 flex items-center space-x-1"
                    >
                      <FiStar />
                      <span>Favorite</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="p-8 text-center">
          <p className="text-gray-500">No arbitrage opportunities found</p>
          <p className="text-sm text-gray-400 mt-2">Try adjusting your filters or calculate new opportunities</p>
        </div>
      )}
    </div>
  );
};

export default ArbitrageTable;
