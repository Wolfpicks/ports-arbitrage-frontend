import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { QueryClientProvider, QueryClient } from 'react-query';
import { AuthProvider } from '../context/AuthContext';
import LoginForm from '../components/LoginForm';
import '@testing-library/jest-dom';
import { act } from 'react-dom/test-utils';
import * as api from '../utils/api';

// Mock the router
jest.mock('next/router', () => ({
  useRouter: () => ({
    push: jest.fn(),
  }),
}));

// Mock the API calls
jest.mock('../utils/api', () => ({
  authAPI: {
    login: jest.fn(),
  },
}));

// Mock the toast notifications
jest.mock('react-toastify', () => ({
  toast: {
    success: jest.fn(),
    error: jest.fn(),
    info: jest.fn(),
  },
}));

// Mock js-cookie
jest.mock('js-cookie', () => ({
  set: jest.fn(),
  get: jest.fn(),
  remove: jest.fn(),
}));

// Create a test QueryClient
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
    },
  },
});

// Wrapper component for testing
const wrapper = ({ children }) => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>{children}</AuthProvider>
  </QueryClientProvider>
);

describe('LoginForm', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('renders login form', () => {
    render(<LoginForm />, { wrapper });
    
    expect(screen.getByText('Login to ArbitrageHub')).toBeInTheDocument();
    expect(screen.getByLabelText(/Email Address/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Password/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Login/i })).toBeInTheDocument();
    expect(screen.getByText(/Don't have an account\?/i)).toBeInTheDocument();
    expect(screen.getByText(/Register here/i)).toBeInTheDocument();
  });

  test('validates form inputs', async () => {
    render(<LoginForm />, { wrapper });
    
    // Submit form without filling in fields
    fireEvent.click(screen.getByRole('button', { name: /Login/i }));
    
    // Check for validation errors
    await waitFor(() => {
      expect(screen.getByText(/Email is required/i)).toBeInTheDocument();
      expect(screen.getByText(/Password is required/i)).toBeInTheDocument();
    });
    
    // Fill in email with invalid format
    fireEvent.change(screen.getByLabelText(/Email Address/i), {
      target: { value: 'invalid-email' },
    });
    
    // Check for email format validation
    await waitFor(() => {
      expect(screen.getByText(/Invalid email address/i)).toBeInTheDocument();
    });
  });

  test('submits form with valid data', async () => {
    // Mock successful login
    api.authAPI.login.mockResolvedValueOnce({
      data: { access_token: 'test-token', token_type: 'bearer' },
    });
    
    render(<LoginForm />, { wrapper });
    
    // Fill in form with valid data
    fireEvent.change(screen.getByLabelText(/Email Address/i), {
      target: { value: 'test@example.com' },
    });
    
    fireEvent.change(screen.getByLabelText(/Password/i), {
      target: { value: 'password123' },
    });
    
    // Submit form
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: /Login/i }));
    });
    
    // Check if login API was called with correct data
    expect(api.authAPI.login).toHaveBeenCalledWith(
      'test@example.com',
      'password123'
    );
  });

  test('handles login error', async () => {
    // Mock failed login
    api.authAPI.login.mockRejectedValueOnce(new Error('Login failed'));
    
    render(<LoginForm />, { wrapper });
    
    // Fill in form with valid data
    fireEvent.change(screen.getByLabelText(/Email Address/i), {
      target: { value: 'test@example.com' },
    });
    
    fireEvent.change(screen.getByLabelText(/Password/i), {
      target: { value: 'password123' },
    });
    
    // Submit form
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: /Login/i }));
    });
    
    // Check if error message is displayed
    await waitFor(() => {
      expect(screen.getByText(/Invalid email or password/i)).toBeInTheDocument();
    });
  });
});
