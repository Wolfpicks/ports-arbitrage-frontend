import { render, screen, waitFor } from '@testing-library/react';
import { QueryClientProvider, QueryClient } from 'react-query';
import { AuthProvider } from '../context/AuthContext';
import Dashboard from '../pages/dashboard';
import '@testing-library/jest-dom';
import * as api from '../utils/api';

// Mock the router
jest.mock('next/router', () => ({
  useRouter: () => ({
    push: jest.fn(),
  }),
}));

// Mock the API calls
jest.mock('../utils/api', () => ({
  arbitrageAPI: {
    getArbitrageOpportunities: jest.fn(),
    calculateArbitrageOpportunities: jest.fn(),
  },
  oddsAPI: {
    getLatestOdds: jest.fn(),
    refreshOdds: jest.fn(),
  },
}));

// Mock the auth context
jest.mock('../context/AuthContext', () => ({
  useAuth: () => ({
    isAuthenticated: true,
    user: { id: 1, email: 'test@example.com' },
    loading: false,
  }),
}));

// Mock the Layout component
jest.mock('../components/Layout', () => {
  return {
    __esModule: true,
    default: ({ children, title }) => (
      <div data-testid="mock-layout" title={title}>
        {children}
      </div>
    ),
  };
});

// Mock the ArbitrageTable component
jest.mock('../components/ArbitrageTable', () => {
  return {
    __esModule: true,
    default: () => <div data-testid="mock-arbitrage-table">Arbitrage Table</div>,
  };
});

// Mock the toast notifications
jest.mock('react-toastify', () => ({
  toast: {
    success: jest.fn(),
    error: jest.fn(),
    info: jest.fn(),
  },
}));

// Create a test QueryClient
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
    },
  },
});

// Sample data
const mockArbitrageData = [
  {
    id: 1,
    profit_margin: 2.5,
    // other properties...
  },
  {
    id: 2,
    profit_margin: 1.8,
    // other properties...
  },
];

const mockOddsData = [
  {
    id: 1,
    sportsbook: { name: 'DraftKings' },
    event: { id: 101, sport: 'basketball' },
    // other properties...
  },
  {
    id: 2,
    sportsbook: { name: 'FanDuel' },
    event: { id: 102, sport: 'football' },
    // other properties...
  },
  {
    id: 3,
    sportsbook: { name: 'BetMGM' },
    event: { id: 101, sport: 'basketball' },
    // other properties...
  },
];

// Wrapper component for testing
const wrapper = ({ children }) => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>{children}</AuthProvider>
  </QueryClientProvider>
);

describe('Dashboard', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    
    // Mock successful API responses
    api.arbitrageAPI.getArbitrageOpportunities.mockResolvedValue({
      data: mockArbitrageData,
    });
    
    api.oddsAPI.getLatestOdds.mockResolvedValue({
      data: mockOddsData,
    });
    
    api.oddsAPI.refreshOdds.mockResolvedValue({
      data: { message: 'Odds refreshed successfully' },
    });
    
    api.arbitrageAPI.calculateArbitrageOpportunities.mockResolvedValue({
      data: { message: 'Calculation successful', opportunities_found: 2 },
    });
  });

  test('renders dashboard with stats and arbitrage table', async () => {
    render(<Dashboard />, { wrapper });
    
    // Check if layout is rendered with correct title
    expect(screen.getByTestId('mock-layout')).toHaveAttribute(
      'title',
      'Dashboard | Sports Betting Arbitrage'
    );
    
    // Check if dashboard title is rendered
    expect(screen.getByText('Dashboard')).toBeInTheDocument();
    
    // Wait for stats to load
    await waitFor(() => {
      expect(screen.getByText('Arbitrage Opportunities')).toBeInTheDocument();
      expect(screen.getByText('Highest Profit Margin')).toBeInTheDocument();
      expect(screen.getByText('Sportsbooks')).toBeInTheDocument();
      expect(screen.getByText('Events Tracked')).toBeInTheDocument();
    });
    
    // Check if arbitrage table is rendered
    expect(screen.getByTestId('mock-arbitrage-table')).toBeInTheDocument();
    
    // Check if API calls were made
    expect(api.arbitrageAPI.getArbitrageOpportunities).toHaveBeenCalled();
    expect(api.oddsAPI.getLatestOdds).toHaveBeenCalled();
    expect(api.oddsAPI.refreshOdds).toHaveBeenCalled();
    expect(api.arbitrageAPI.calculateArbitrageOpportunities).toHaveBeenCalled();
  });

  test('displays correct stats based on data', async () => {
    render(<Dashboard />, { wrapper });
    
    // Wait for stats to load
    await waitFor(() => {
      // Check total arbitrage opportunities (2 from mock data)
      expect(screen.getByText('2')).toBeInTheDocument();
      
      // Check highest profit margin (2.5% from mock data)
      expect(screen.getByText('2.50%')).toBeInTheDocument();
      
      // Check total sportsbooks (3 unique from mock data)
      expect(screen.getByText('3')).toBeInTheDocument();
      
      // Check total events (2 unique from mock data)
      expect(screen.getByText('2')).toBeInTheDocument();
    });
  });
});
