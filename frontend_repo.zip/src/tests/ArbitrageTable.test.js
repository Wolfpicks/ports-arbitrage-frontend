import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { QueryClientProvider, QueryClient } from 'react-query';
import { AuthProvider } from '../context/AuthContext';
import ArbitrageTable from '../components/ArbitrageTable';
import '@testing-library/jest-dom';
import { act } from 'react-dom/test-utils';
import * as api from '../utils/api';

// Mock the API calls
jest.mock('../utils/api', () => ({
  arbitrageAPI: {
    getArbitrageOpportunities: jest.fn(),
    calculateArbitrageOpportunities: jest.fn(),
  },
  favoritesAPI: {
    addFavorite: jest.fn(),
  }
}));

// Mock the auth context
jest.mock('../context/AuthContext', () => ({
  useAuth: () => ({
    isAuthenticated: true,
  }),
}));

// Mock the toast notifications
jest.mock('react-toastify', () => ({
  toast: {
    success: jest.fn(),
    error: jest.fn(),
    info: jest.fn(),
  },
}));

// Create a test QueryClient
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
    },
  },
});

// Sample arbitrage data
const mockArbitrageData = [
  {
    id: 1,
    event: {
      id: 101,
      name: 'Team A vs Team B',
      sport: 'basketball',
      league: 'NBA',
      date: '2025-04-15T19:00:00',
    },
    profit_margin: 2.5,
    outcome_details: {
      'Team A': {
        sportsbook: 'DraftKings',
        odds_decimal: 2.10,
        odds_american: 110,
        implied_probability: 0.476,
        optimal_stake: 47.62,
      },
      'Team B': {
        sportsbook: 'FanDuel',
        odds_decimal: 1.95,
        odds_american: -105,
        implied_probability: 0.513,
        optimal_stake: 51.28,
      },
    },
    detected_at: '2025-04-01T04:30:00',
  },
];

// Wrapper component for testing
const wrapper = ({ children }) => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>{children}</AuthProvider>
  </QueryClientProvider>
);

describe('ArbitrageTable', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    
    // Mock successful API response
    api.arbitrageAPI.getArbitrageOpportunities.mockResolvedValue({
      data: mockArbitrageData,
    });
  });

  test('renders arbitrage table with data', async () => {
    render(<ArbitrageTable />, { wrapper });
    
    // Check loading state first
    expect(screen.getByRole('status')).toBeInTheDocument();
    
    // Wait for data to load
    await waitFor(() => {
      expect(screen.getByText('Arbitrage Opportunities')).toBeInTheDocument();
    });
    
    // Check if data is displayed
    expect(screen.getByText('Team A vs Team B')).toBeInTheDocument();
    expect(screen.getByText('+2.50%')).toBeInTheDocument();
    expect(screen.getByText('Team A')).toBeInTheDocument();
    expect(screen.getByText('Team B')).toBeInTheDocument();
    expect(screen.getByText('DraftKings')).toBeInTheDocument();
    expect(screen.getByText('FanDuel')).toBeInTheDocument();
  });

  test('filters arbitrage opportunities', async () => {
    // Mock filtered API response
    api.arbitrageAPI.getArbitrageOpportunities.mockImplementation((minProfit, sport) => {
      if (minProfit > 3) {
        return Promise.resolve({ data: [] });
      }
      if (sport === 'football') {
        return Promise.resolve({ data: [] });
      }
      return Promise.resolve({ data: mockArbitrageData });
    });
    
    render(<ArbitrageTable />, { wrapper });
    
    // Wait for data to load
    await waitFor(() => {
      expect(screen.getByText('Arbitrage Opportunities')).toBeInTheDocument();
    });
    
    // Change min profit filter to 4%
    fireEvent.change(screen.getByLabelText(/Min Profit:/i), {
      target: { value: '4' },
    });
    
    // Wait for filtered data
    await waitFor(() => {
      expect(screen.getByText('No arbitrage opportunities found')).toBeInTheDocument();
    });
    
    // Change min profit back to 2%
    fireEvent.change(screen.getByLabelText(/Min Profit:/i), {
      target: { value: '2' },
    });
    
    // Wait for data to appear again
    await waitFor(() => {
      expect(screen.getByText('Team A vs Team B')).toBeInTheDocument();
    });
    
    // Change sport filter to football
    fireEvent.change(screen.getByRole('combobox'), {
      target: { value: 'football' },
    });
    
    // Wait for filtered data
    await waitFor(() => {
      expect(screen.getByText('No arbitrage opportunities found')).toBeInTheDocument();
    });
  });

  test('calculates new arbitrage opportunities', async () => {
    // Mock successful calculation
    api.arbitrageAPI.calculateArbitrageOpportunities.mockResolvedValue({
      data: { message: 'Calculation successful', opportunities_found: 3 },
    });
    
    render(<ArbitrageTable />, { wrapper });
    
    // Wait for data to load
    await waitFor(() => {
      expect(screen.getByText('Arbitrage Opportunities')).toBeInTheDocument();
    });
    
    // Click calculate button
    await act(async () => {
      fireEvent.click(screen.getByText('Calculate'));
    });
    
    // Check if calculation API was called
    expect(api.arbitrageAPI.calculateArbitrageOpportunities).toHaveBeenCalled();
  });

  test('adds opportunity to favorites', async () => {
    // Mock successful favorite addition
    api.favoritesAPI.addFavorite.mockResolvedValue({
      data: { message: 'Added to favorites' },
    });
    
    render(<ArbitrageTable />, { wrapper });
    
    // Wait for data to load
    await waitFor(() => {
      expect(screen.getByText('Arbitrage Opportunities')).toBeInTheDocument();
    });
    
    // Click favorite button
    await act(async () => {
      fireEvent.click(screen.getByText('Favorite'));
    });
    
    // Check if favorite API was called with correct ID
    expect(api.favoritesAPI.addFavorite).toHaveBeenCalledWith(1);
  });
});
